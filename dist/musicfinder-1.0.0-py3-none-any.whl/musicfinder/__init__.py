from .api import Finder





__author__ = 'Ali Ranjbar, GitHub link: https://github.com/aliranjbar00'
__version__ = '1.0.0'
__all__ = ['search']